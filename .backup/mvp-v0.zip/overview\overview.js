const store = require('../../utils/store')
const { countPending } = require('../../utils/schema')
const { buildTrip, buildShareText, sceneLine } = require('../../utils/trip')
const { toDateText, addDays } = require('../../utils/format')
const { copy } = require('../../utils/clipboard')

Page({
  data: {
    trip: null,
    pending: 0,
    dayCards: [],
    sceneLine: ''
  },

  onLoad(query) {
    this.tripId = query.id || ''
    this.load()
  },

  onShow() {
    if (this.tripId && this.data.trip) this.load()
  },

  load() {
    const trip = store.getTrip(this.tripId)
    if (!trip) {
      wx.showToast({ title: '行程不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }

    const startDate = (trip.scene && trip.scene.startDate) || ''
    const dayCards = trip.days.map(day => ({
      index: day.index,
      label: 'D' + day.index,
      date: startDate ? toDateText(addDays(startDate, day.index - 1)) : '',
      stations: day.items.map(item => item.title).join(' → '),
      count: day.items.length
    }))

    this.setData({
      trip,
      pending: countPending(trip),
      dayCards,
      sceneLine: sceneLine(trip.scene)
    })
    wx.setNavigationBarTitle({ title: trip.title || '行程总览' })
  },

  onOpenDay(e) {
    const day = e.currentTarget.dataset.index
    wx.navigateTo({ url: '/pages/day/day?id=' + this.tripId + '&day=' + day })
  },

  onCopyAll() {
    copy(buildShareText(this.data.trip), '整份行程已复制')
  },

  onRegenerate() {
    const self = this
    wx.showModal({
      title: '重新排一遍？',
      content: '会按当前场景覆盖这份路书，之前的删改会丢失',
      confirmText: '重新生成',
      success(res) {
        if (!res.confirm) return
        const old = self.data.trip
        const trip = buildTrip(old.scene || {})
        trip.id = self.tripId
        trip.createdAt = old.createdAt
        store.saveTrip(trip)
        self.load()
        wx.showToast({ title: '已重新生成', icon: 'none' })
      }
    })
  },

  onMyTap() {
    wx.navigateTo({ url: '/pages/my/my' })
  }
})
