Component({
  options: {
    styleIsolation: 'apply-shared'
  },
  properties: {
    show: { type: Boolean, value: false },
    current: { type: String, value: '' },
    planb: { type: Object, value: null }
  },
  methods: {
    noop() {},
    onClose() {
      this.triggerEvent('close')
    },
    onConfirm() {
      this.triggerEvent('confirm')
    }
  }
})
