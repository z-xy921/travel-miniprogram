const { normalizeTrip } = require('./schema')
const { matchSeed } = require('../data/seeds')
const { durationText } = require('./format')

// 站点之间的默认缓冲（步行/停车/找门脸），只是排期假设，不是事实
const BUFFER_MIN = 30

function pad2(n) {
  return n < 10 ? '0' + n : '' + n
}

function parseTime(time) {
  const parts = String(time || '').split(':')
  if (parts.length !== 2) return null
  const h = Number(parts[0])
  const m = Number(parts[1])
  if (isNaN(h) || isNaN(m)) return null
  return h * 60 + m
}

function toTime(minutes) {
  const total = ((minutes % 1440) + 1440) % 1440
  return pad2(Math.floor(total / 60)) + ':' + pad2(total % 60)
}

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

// 按「第一站的开始时间 + 每站停留 + 缓冲」重新推一遍时间轴
function reschedule(items) {
  let cursor = parseTime(items[0] && items[0].time)
  if (cursor === null) cursor = 9 * 60
  return items.map(item => {
    const time = toTime(cursor)
    cursor += (item.durationMin || 60) + BUFFER_MIN
    return Object.assign({}, item, { time })
  })
}

function buildTrip(scene) {
  const seed = matchSeed(scene.preference)
  const dayCount = Math.max(1, Math.min(Number(scene.days) || 2, seed.days.length))
  const now = Date.now()
  const days = seed.days.slice(0, dayCount).map((items, dayIndex) => ({
    index: dayIndex + 1,
    items: clone(items)
  }))

  return normalizeTrip({
    id: 'trip_' + now,
    title: (scene.from || '未填出发地') + '出发 · ' + seed.label + '线',
    createdAt: now,
    updatedAt: now,
    source: 'seed',
    seedKey: seed.key,
    scene: clone(scene),
    sourceRefs: [],
    days
  })
}

// 现场换站：纯本地替换，不调 AI，时间槽位保持不变
function swapWithPlanB(items, itemId) {
  const index = items.findIndex(item => item.id === itemId)
  if (index < 0) return items
  const current = items[index]
  const planB = current.planB
  if (!planB) return items

  const hasFacts = planB.facts && Object.keys(planB.facts).length
  const next = items.slice()
  next[index] = Object.assign({}, current, {
    title: planB.title,
    place: planB.place,
    why: planB.swapReason || '原计划受阻时的同区域备选',
    peakTip: '',
    facts: hasFacts
      ? planB.facts
      : { open: { value: '暂无可靠信息，请到现场或官方渠道确认', state: 'pending' } },
    planBUsed: true,
    swappedFrom: current.planBUsed ? current.swappedFrom : current.title
  })
  return next
}

function removeItem(items, itemId) {
  return reschedule(items.filter(item => item.id !== itemId))
}

function moveItem(items, itemId, direction) {
  const index = items.findIndex(item => item.id === itemId)
  const target = index + direction
  if (index < 0 || target < 0 || target >= items.length) return items
  const next = items.slice()
  const tmp = next[index]
  next[index] = next[target]
  next[target] = tmp
  return reschedule(next)
}

function sceneLine(scene) {
  const s = scene || {}
  const transport = (s.transport || []).map(key => (key === 'drive' ? '自驾' : '公交')).join(' / ')
  const partyMap = { couple: '2 人', friends: '朋友同行', family: '带娃', elder: '带长辈' }
  return [
    s.from,
    (s.days || 2) + ' 天',
    s.budget ? '人均 ≤' + s.budget + ' 元' : '',
    partyMap[s.party] || '',
    transport
  ].filter(Boolean).join(' · ')
}

function buildShareText(trip) {
  const lines = []
  lines.push('【' + trip.title + '】')
  lines.push(sceneLine(trip.scene))
  lines.push('')
  trip.days.forEach(day => {
    lines.push('D' + day.index)
    day.items.forEach(item => {
      const duration = durationText(item.durationMin)
      lines.push(
        item.time + ' ' + item.title + (duration ? '（' + duration + '）' : '') + (item.place ? ' / ' + item.place : '')
      )
    })
    lines.push('')
  })
  lines.push('营业时间、预约、费用、车程均为推测信息，出行前请务必自行核实。')
  return lines.join('\n')
}

function buildDayText(items) {
  const lines = items.map(item => item.time + ' ' + item.title + (item.place ? ' / ' + item.place : ''))
  lines.push('')
  lines.push('（时间为排期建议，营业时间/预约/车程待核实）')
  return lines.join('\n')
}

module.exports = {
  buildTrip,
  swapWithPlanB,
  removeItem,
  moveItem,
  buildShareText,
  buildDayText,
  sceneLine,
  reschedule
}
