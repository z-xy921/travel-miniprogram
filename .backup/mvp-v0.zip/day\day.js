const store = require('../../utils/store')
const { countPending, factsList } = require('../../utils/schema')
const { swapWithPlanB, removeItem, moveItem, buildDayText } = require('../../utils/trip')
const { durationText, toDateText, addDays } = require('../../utils/format')
const { copy } = require('../../utils/clipboard')

Page({
  data: {
    trip: null,
    tabs: [],
    dayIndex: 0,
    items: [],
    pending: 0,
    editing: false,
    sheet: { show: false, itemId: '', current: '', planB: null }
  },

  onLoad(query) {
    this.tripId = query.id || ''
    this.initialDay = Number(query.day) || 1
    this.loaded = false
    this.load(true)
  },

  onShow() {
    // 从别的页面回来时同步一次，保留当前正在看的 Day
    if (this.loaded) this.load(false)
  },

  load(isFirst) {
    const trip = store.getTrip(this.tripId)
    if (!trip) {
      wx.showToast({ title: '行程不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }

    const startDate = (trip.scene && trip.scene.startDate) || ''
    const tabs = trip.days.map(day => ({
      index: day.index,
      label: 'D' + day.index,
      date: startDate ? toDateText(addDays(startDate, day.index - 1)) : ''
    }))
    const dayIndex = isFirst
      ? Math.max(0, Math.min(this.initialDay - 1, trip.days.length - 1))
      : Math.max(0, Math.min(this.data.dayIndex, trip.days.length - 1))

    this.setData({ trip, tabs, dayIndex })
    this.render()
    wx.setNavigationBarTitle({ title: trip.title || '路书' })
    this.loaded = true
  },

  render() {
    const trip = this.data.trip
    if (!trip || !trip.days.length) return
    const dayIndex = Math.max(0, Math.min(this.data.dayIndex, trip.days.length - 1))
    const day = trip.days[dayIndex]
    const items = day.items.map((item, index) => Object.assign({}, item, {
      durationText: durationText(item.durationMin),
      factsList: factsList(item.facts),
      isFirst: index === 0,
      isLast: index === day.items.length - 1
    }))
    this.setData({ items, dayIndex, pending: countPending(trip) })
  },

  persist(items) {
    const trip = this.data.trip
    trip.days[this.data.dayIndex].items = items
    store.saveTrip(trip)
    this.setData({ trip })
    this.render()
  },

  findItem(id) {
    return this.data.items.filter(item => item.id === id)[0]
  },

  onDayChange(e) {
    const index = Number(e.currentTarget.dataset.index)
    if (index === this.data.dayIndex) return
    this.setData({ dayIndex: index, editing: false })
    this.render()
  },

  onToggleEdit() {
    this.setData({ editing: !this.data.editing })
  },

  onCopyItem(e) {
    const item = this.findItem(e.detail.id)
    if (!item) return
    copy(item.title + ' ' + (item.place || ''), '地址已复制')
  },

  onSwap(e) {
    const item = this.findItem(e.detail.id)
    if (!item || !item.planB) return
    this.setData({
      sheet: { show: true, itemId: item.id, current: item.title, planB: item.planB }
    })
  },

  onCloseSheet() {
    this.setData({ 'sheet.show': false })
  },

  onConfirmSwap() {
    const sheet = this.data.sheet
    const day = this.data.trip.days[this.data.dayIndex]
    this.persist(swapWithPlanB(day.items, sheet.itemId))
    this.setData({ 'sheet.show': false })
    wx.showToast({ title: '已换成备选', icon: 'none' })
  },

  onRemove(e) {
    const id = e.detail.id
    const self = this
    wx.showModal({
      title: '删掉这一站？',
      content: '后面的时间会按停留时长重新排一遍',
      confirmText: '删掉',
      confirmColor: '#b91c1c',
      success(res) {
        if (!res.confirm) return
        const day = self.data.trip.days[self.data.dayIndex]
        self.persist(removeItem(day.items, id))
        wx.showToast({ title: '已删除，时间已重排', icon: 'none' })
      }
    })
  },

  onUp(e) {
    this.move(e.detail.id, -1)
  },

  onDown(e) {
    this.move(e.detail.id, 1)
  },

  move(id, direction) {
    const day = this.data.trip.days[this.data.dayIndex]
    this.persist(moveItem(day.items, id, direction))
  },

  onCopyDay() {
    const day = this.data.trip.days[this.data.dayIndex]
    copy(buildDayText(day.items), '今天的时间轴已复制')
  },

  onBackOverview() {
    wx.navigateBack()
  }
})
