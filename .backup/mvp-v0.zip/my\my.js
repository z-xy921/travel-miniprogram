const store = require('../../utils/store')
const { toDateText } = require('../../utils/format')

Page({
  data: { list: [] },

  onShow() {
    this.load()
  },

  load() {
    const list = store.listTrips().map(item => ({
      id: item.id,
      title: item.title || '未命名路书',
      dateText: toDateText(item.startDate) || '未设置日期',
      days: item.days || 1,
      source: item.source || 'seed'
    }))
    this.setData({ list })
  },

  onOpen(e) {
    wx.navigateTo({ url: '/pages/overview/overview?id=' + e.currentTarget.dataset.id })
  },

  onDelete(e) {
    const id = e.currentTarget.dataset.id
    const self = this
    wx.showModal({
      title: '删除这份路书？',
      content: '只删本机记录，删了找不回来',
      confirmText: '删除',
      confirmColor: '#b91c1c',
      success(res) {
        if (!res.confirm) return
        store.removeTrip(id)
        self.load()
        wx.showToast({ title: '已删除', icon: 'none' })
      }
    })
  },

  onGoIndex() {
    wx.reLaunch({ url: '/pages/index/index' })
  }
})
