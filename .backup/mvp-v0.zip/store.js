const INDEX_KEY = 'mp_trips_index'
const TRIP_PREFIX = 'mp_trip_'
const DRAFT_KEY = 'mp_form_draft'
const MAX_TRIPS = 10

function readIndex() {
  const list = wx.getStorageSync(INDEX_KEY)
  return Array.isArray(list) ? list : []
}

function writeIndex(list) {
  wx.setStorageSync(INDEX_KEY, list)
}

function listTrips() {
  return readIndex().slice().sort((a, b) => b.updatedAt - a.updatedAt)
}

function getTrip(id) {
  if (!id) return null
  const trip = wx.getStorageSync(TRIP_PREFIX + id)
  return trip && trip.id ? trip : null
}

function saveTrip(trip) {
  if (!trip || !trip.id) return null
  trip.updatedAt = Date.now()
  wx.setStorageSync(TRIP_PREFIX + trip.id, trip)

  const list = readIndex().filter(item => item.id !== trip.id)
  list.unshift({
    id: trip.id,
    title: trip.title,
    startDate: (trip.scene && trip.scene.startDate) || '',
    days: (trip.days || []).length,
    source: trip.source || 'seed',
    updatedAt: trip.updatedAt
  })
  list.sort((a, b) => b.updatedAt - a.updatedAt)

  // 只保留最近 10 份，超出的连详情一起删掉，避免本地存储无限增长
  list.slice(MAX_TRIPS).forEach(item => wx.removeStorageSync(TRIP_PREFIX + item.id))
  writeIndex(list.slice(0, MAX_TRIPS))
  return trip
}

function removeTrip(id) {
  wx.removeStorageSync(TRIP_PREFIX + id)
  writeIndex(readIndex().filter(item => item.id !== id))
}

function saveDraft(scene) {
  wx.setStorageSync(DRAFT_KEY, scene)
}

function getDraft() {
  const draft = wx.getStorageSync(DRAFT_KEY)
  return draft && typeof draft === 'object' ? draft : null
}

// 同一场景（出发地/日期/天数/人数/预算/交通/偏好都相同）就复用旧记录，
// 避免反复点「生成」在列表里堆出一串一模一样的路书
function findTripIdByScene(scene) {
  if (!scene) return ''
  const keys = ['from', 'startDate', 'days', 'party', 'budget', 'preference']
  const norm = value => (Array.isArray(value) ? value.slice().sort().join(',') : String(value || ''))

  const list = listTrips()
  for (let i = 0; i < list.length; i += 1) {
    const trip = getTrip(list[i].id)
    if (!trip || !trip.scene) continue
    const sameScene = keys.every(key => norm(trip.scene[key]) === norm(scene[key]))
    const sameTransport = norm(trip.scene.transport) === norm(scene.transport)
    if (sameScene && sameTransport) return trip.id
  }
  return ''
}

module.exports = {
  MAX_TRIPS,
  listTrips,
  getTrip,
  saveTrip,
  removeTrip,
  findTripIdByScene,
  saveDraft,
  getDraft
}
