const store = require('../../utils/store')
const { buildTrip } = require('../../utils/trip')
const { formatDate, addDays } = require('../../utils/format')

const PARTIES = [
  { key: 'couple', label: '情侣 / 2 人' },
  { key: 'friends', label: '朋友同行' },
  { key: 'family', label: '带娃' },
  { key: 'elder', label: '带长辈' }
]
const BUDGETS = [300, 600, 1000]
const TRANSPORTS = [
  { key: 'drive', label: '自驾' },
  { key: 'transit', label: '公共交通' }
]

// WXML 里不做方法调用，选中态提前算成字段
function buildTransports(selected) {
  const list = selected || []
  return TRANSPORTS.map(item => ({
    key: item.key,
    label: item.label,
    active: list.indexOf(item.key) > -1
  }))
}
const PREFERENCES = [
  { key: 'shoot', label: '出片优先', desc: '光线好 / 机位密 / 步行少' },
  { key: 'relax', label: '松弛优先', desc: '不赶点 / 有座位 / 能午休' },
  { key: 'family', label: '带娃优先', desc: '少排队 / 有兜底 / 好停车' }
]

const GEN_TEXTS = [
  '正在按「少排队」重排顺序…',
  '正在给每一站配一个备选…',
  '正在把自驾和公交的时间分开算…'
]
const TICK_MS = 2400
const SLOW_MS = 8000
// M1 用种子数据，人为留一点延迟，接上云函数后这段体验不用重写
const GEN_DELAY = 900

function nextSaturday() {
  const today = new Date()
  const diff = (6 - today.getDay() + 7) % 7
  return new Date(today.getFullYear(), today.getMonth(), today.getDate() + diff)
}

Page({
  data: {
    parties: PARTIES,
    budgets: BUDGETS,
    transports: buildTransports(['drive']),
    preferences: PREFERENCES,
    form: {
      from: '',
      startDate: '',
      days: 2,
      party: 'couple',
      budget: 600,
      transport: ['drive'],
      preference: 'relax'
    },
    minDate: '',
    maxDate: '',
    generating: false,
    slow: false,
    genText: GEN_TEXTS[0]
  },

  onLoad() {
    const today = new Date()
    const draft = store.getDraft()
    const form = Object.assign(
      {
        from: '',
        startDate: formatDate(nextSaturday()),
        days: 2,
        party: 'couple',
        budget: 600,
        transport: ['drive'],
        preference: 'relax'
      },
      draft || {}
    )
    if (!Array.isArray(form.transport) || !form.transport.length) form.transport = ['drive']

    this.setData({
      form,
      transports: buildTransports(form.transport),
      minDate: formatDate(today),
      maxDate: addDays(formatDate(today), 180)
    })
  },

  onUnload() {
    this.stopTicker()
  },

  onFromInput(e) {
    this.setData({ 'form.from': e.detail.value })
  },

  onDateChange(e) {
    this.setData({ 'form.startDate': e.detail.value })
  },

  onDaysTap(e) {
    this.setData({ 'form.days': Number(e.currentTarget.dataset.days) })
  },

  onPartyTap(e) {
    const key = e.currentTarget.dataset.key
    const patch = { 'form.party': key }
    // 带娃时默认切到带娃线，少让用户做一次选择
    if (key === 'family') patch['form.preference'] = 'family'
    this.setData(patch)
  },

  onBudgetTap(e) {
    this.setData({ 'form.budget': Number(e.currentTarget.dataset.budget) })
  },

  onTransportTap(e) {
    const key = e.currentTarget.dataset.key
    const list = this.data.form.transport.slice()
    const index = list.indexOf(key)
    if (index > -1) {
      if (list.length === 1) {
        wx.showToast({ title: '至少选一种交通方式', icon: 'none' })
        return
      }
      list.splice(index, 1)
    } else {
      list.push(key)
    }
    this.setData({ 'form.transport': list, transports: buildTransports(list) })
  },

  onPrefTap(e) {
    this.setData({ 'form.preference': e.currentTarget.dataset.key })
  },

  onGenerate() {
    if (this.data.generating) return
    const form = Object.assign({}, this.data.form)
    form.from = (form.from || '').trim()
    if (!form.from) {
      wx.showToast({ title: '先填一下出发地', icon: 'none' })
      return
    }

    store.saveDraft(form)
    this.setData({ 'form.from': form.from, generating: true, slow: false, genText: GEN_TEXTS[0] })
    this.startTicker()

    this.genTimer = setTimeout(() => {
      const trip = buildTrip(form)
      // 同场景重复生成时复用旧记录，不在列表里堆重复项
      const existedId = store.findTripIdByScene(form)
      if (existedId) {
        const old = store.getTrip(existedId)
        trip.id = existedId
        trip.createdAt = (old && old.createdAt) || trip.createdAt
      }
      store.saveTrip(trip)
      this.stopTicker()
      this.setData({ generating: false })
      wx.navigateTo({ url: '/pages/overview/overview?id=' + trip.id })
    }, GEN_DELAY)
  },

  startTicker() {
    let index = 0
    this.tickTimer = setInterval(() => {
      index = (index + 1) % GEN_TEXTS.length
      this.setData({ genText: GEN_TEXTS[index] })
    }, TICK_MS)
    this.slowTimer = setTimeout(() => this.setData({ slow: true }), SLOW_MS)
  },

  stopTicker() {
    if (this.tickTimer) {
      clearInterval(this.tickTimer)
      this.tickTimer = null
    }
    if (this.slowTimer) {
      clearTimeout(this.slowTimer)
      this.slowTimer = null
    }
    if (this.genTimer) {
      clearTimeout(this.genTimer)
      this.genTimer = null
    }
  },

  onSlowWait() {
    this.setData({ slow: false, genText: '还在生成，通常不会超过 12 秒…' })
    this.slowTimer = setTimeout(() => this.setData({ slow: true }), SLOW_MS)
  },

  onViewExample() {
    this.stopTicker()
    const form = Object.assign({}, this.data.form, {
      from: this.data.form.from || '示例出发地'
    })
    const trip = buildTrip(form)
    store.saveTrip(trip)
    this.setData({ generating: false })
    wx.navigateTo({ url: '/pages/overview/overview?id=' + trip.id })
  },

  onMyTap() {
    wx.navigateTo({ url: '/pages/my/my' })
  },

  onAboutTap() {
    wx.navigateTo({ url: '/pages/about/about' })
  }
})
