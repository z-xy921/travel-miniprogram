Component({
  options: {
    styleIsolation: 'apply-shared'
  },
  properties: {
    item: { type: Object, value: {} },
    first: { type: Boolean, value: false },
    last: { type: Boolean, value: false },
    editing: { type: Boolean, value: false }
  },
  methods: {
    onCopy() {
      this.triggerEvent('copy', { id: this.data.item.id })
    },
    onSwap() {
      this.triggerEvent('swap', { id: this.data.item.id })
    },
    onUp() {
      this.triggerEvent('up', { id: this.data.item.id })
    },
    onDown() {
      this.triggerEvent('down', { id: this.data.item.id })
    },
    onRemove() {
      this.triggerEvent('remove', { id: this.data.item.id })
    }
  }
})
