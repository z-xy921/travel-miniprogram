// 事实字段只允许 pending 一种状态：
// AI 给出的营业时间、预约要求、票价、车程都不做确定性判断，
// 任何“已确认”的状态在数据层就被降级，避免渲染出假权威。
const FACT_META = [
  { key: 'open', label: '营业时间' },
  { key: 'reserve', label: '预约' },
  { key: 'fee', label: '费用' },
  { key: 'drive', label: '自驾' },
  { key: 'transit', label: '公交/地铁' }
]

function normalizeFact(fact) {
  if (!fact || typeof fact.value !== 'string') return null
  const value = fact.value.trim()
  if (!value) return null
  return { value, state: 'pending' }
}

function normalizeFacts(raw) {
  const out = {}
  FACT_META.forEach(meta => {
    const one = normalizeFact(raw && raw[meta.key])
    if (one) out[meta.key] = one
  })
  return out
}

function normalizePlanB(raw) {
  if (!raw || !raw.title) return null
  return {
    title: raw.title,
    place: raw.place || '',
    swapReason: raw.swapReason || '',
    facts: normalizeFacts(raw.facts)
  }
}

function normalizeItem(raw, dayIndex, itemIndex) {
  if (!raw || !raw.title) return null
  const time = /^\d{2}:\d{2}$/.test(raw.time || '') ? raw.time : ''
  return {
    id: raw.id || `it_${dayIndex + 1}_${itemIndex + 1}_${Math.random().toString(36).slice(2, 7)}`,
    time,
    durationMin: Number(raw.durationMin) > 0 ? Number(raw.durationMin) : 0,
    title: raw.title,
    place: raw.place || '',
    why: raw.why || '',
    peakTip: raw.peakTip || '',
    planBUsed: !!raw.planBUsed,
    swappedFrom: raw.swappedFrom || '',
    facts: normalizeFacts(raw.facts),
    planB: normalizePlanB(raw.planB)
  }
}

function normalizeTrip(raw) {
  const source = raw || {}
  const days = (source.days || [])
    .map((day, dayIndex) => {
      const items = (day.items || [])
        .map((item, itemIndex) => normalizeItem(item, dayIndex, itemIndex))
        .filter(Boolean)
      return { index: dayIndex + 1, items }
    })
    .filter(day => day.items.length)
  return Object.assign({}, source, { days })
}

function factsList(facts) {
  return FACT_META.filter(meta => facts && facts[meta.key]).map(meta => ({
    key: meta.key,
    label: meta.label,
    value: facts[meta.key].value,
    state: facts[meta.key].state
  }))
}

function countPending(trip) {
  let total = 0
  ;((trip && trip.days) || []).forEach(day => {
    day.items.forEach(item => {
      total += Object.keys(item.facts || {}).length
    })
  })
  return total
}

module.exports = {
  FACT_META,
  normalizeFacts,
  normalizeTrip,
  factsList,
  countPending
}
